package cats
package syntax

trait TraverseSyntax extends Traverse.ToTraverseOps
