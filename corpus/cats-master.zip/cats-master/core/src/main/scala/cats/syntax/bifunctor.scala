package cats
package syntax

import cats.Bifunctor

trait BifunctorSyntax extends Bifunctor.ToBifunctorOps
