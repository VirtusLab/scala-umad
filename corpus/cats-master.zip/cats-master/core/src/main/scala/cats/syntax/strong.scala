package cats
package syntax

import cats.arrow.Strong

trait StrongSyntax extends Strong.ToStrongOps
