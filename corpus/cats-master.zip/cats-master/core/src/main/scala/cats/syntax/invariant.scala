package cats
package syntax

import cats.Invariant

trait InvariantSyntax extends Invariant.ToInvariantOps
