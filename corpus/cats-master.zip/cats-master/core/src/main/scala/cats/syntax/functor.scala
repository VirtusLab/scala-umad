package cats
package syntax

trait FunctorSyntax extends Functor.ToFunctorOps

