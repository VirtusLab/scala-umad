package cats
package syntax

trait FunctorFilterSyntax extends FunctorFilter.ToFunctorFilterOps
