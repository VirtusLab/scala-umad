package cats
package syntax

import cats.arrow.Arrow

trait ArrowSyntax extends Arrow.ToArrowOps
