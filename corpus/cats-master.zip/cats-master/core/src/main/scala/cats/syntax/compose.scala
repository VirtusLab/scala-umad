package cats
package syntax

import cats.arrow.Compose

trait ComposeSyntax extends Compose.ToComposeOps
