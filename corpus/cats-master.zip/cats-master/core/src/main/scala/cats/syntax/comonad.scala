package cats
package syntax

trait ComonadSyntax extends Comonad.ToComonadOps

