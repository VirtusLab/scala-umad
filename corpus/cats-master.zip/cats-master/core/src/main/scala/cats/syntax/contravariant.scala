package cats
package syntax

import cats.Contravariant

trait ContravariantSyntax extends Contravariant.ToContravariantOps

