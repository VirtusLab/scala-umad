package cats
package syntax

import cats.arrow.Profunctor

trait ProfunctorSyntax extends Profunctor.ToProfunctorOps
