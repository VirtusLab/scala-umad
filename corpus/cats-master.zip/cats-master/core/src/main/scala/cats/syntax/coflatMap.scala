package cats
package syntax

trait CoflatMapSyntax extends CoflatMap.ToCoflatMapOps
