package cats
package syntax

import cats.arrow.Choice

trait ChoiceSyntax extends Choice.ToChoiceOps
