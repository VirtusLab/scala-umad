package cats
package syntax

import cats.arrow.ArrowChoice

trait ArrowChoiceSyntax extends ArrowChoice.ToArrowChoiceOps
