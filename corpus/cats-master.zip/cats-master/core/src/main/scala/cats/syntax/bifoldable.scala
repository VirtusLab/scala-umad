package cats
package syntax

trait BifoldableSyntax extends Bifoldable.ToBifoldableOps
