package cats
package syntax

trait SemigroupKSyntax extends SemigroupK.ToSemigroupKOps
