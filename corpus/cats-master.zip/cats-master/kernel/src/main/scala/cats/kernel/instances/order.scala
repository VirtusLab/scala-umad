package cats.kernel
package instances

trait OrderInstances extends OrderToOrderingConversion

object order extends OrderInstances
