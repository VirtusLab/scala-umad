package cats.kernel
package instances

package object tuple extends TupleInstances
