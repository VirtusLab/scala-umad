package cats.kernel
package instances

trait EqInstances extends EqToEquivConversion

object eq extends EqInstances
