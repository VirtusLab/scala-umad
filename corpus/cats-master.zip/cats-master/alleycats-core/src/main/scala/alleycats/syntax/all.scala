package alleycats.syntax

object all
    extends EmptySyntax
    with FoldableSyntax
